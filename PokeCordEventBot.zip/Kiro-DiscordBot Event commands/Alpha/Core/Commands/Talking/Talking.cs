﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Discord;
using Discord.Commands;
using Discord.WebSocket;
using Newtonsoft.Json;
using System.IO;
using System.Collections.Generic;
using System.Diagnostics;

namespace Alpha.Core.Commands.Talking
{
    class Talking : ModuleBase<SocketCommandContext>
    {

        
    }
}
