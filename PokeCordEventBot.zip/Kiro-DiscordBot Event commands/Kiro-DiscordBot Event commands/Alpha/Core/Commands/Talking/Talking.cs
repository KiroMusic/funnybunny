﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Discord;
using Discord.Commands;
using Discord.WebSocket;
using Newtonsoft.Json;
using System.IO;
using System.Collections.Generic;
using System.Diagnostics;

namespace Alpha.Core.Commands.Talking
{
    public class Talking : ModuleBase<SocketCommandContext>
    {


        [Command("applications")]
        public async Task applications()
        {
            var embed = new EmbedBuilder();

            IReadOnlyCollection<SocketRole> Roles = Program.Client.GetGuild(457746527465766913).GetUser(Context.User.Id).Roles;
            var Owner = Context.Guild.Roles.FirstOrDefault(x => x.Name == "Owner");
            List<SocketRole> userroles = Roles.ToList();
            if (userroles.Contains(Owner) == true)
            {
                embed.WithTitle("***Applications!***");
                embed.WithDescription($"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n**Staff Application**\n*Fill this out to possibly become staff!*\n*https://docs.google.com/forms/d/e/1FAIpQLSfQkQbh_7cYJ33SbEwEHXJB9DiU4ElkPOQ5JWiwlEbAgZYP6g/viewform*\n\n**Host Application**\n*Fill this out to possible become an event host!*\n*https://docs.google.com/forms/u/2/d/e/1FAIpQLSdjTLGumS7v0cK9HvPmwS0hoVYP6AyPu3klxoaBEaiBoc2dLQ/viewformServer*\n\n**Partnership Application**\n*Fill this out to possibly partner with our server*\n*https://docs.google.com/forms/d/e/1FAIpQLSeA38VcZYpIu-mLDXIi8ebg4JeXjBPrB-HB8wncxWDdUV2rlA/viewform*\n\n**NSFW 🔞 application**\n*Fill this out to possibly receive the NSFW role!*\n*https://docs.google.com/forms/d/e/1FAIpQLSc7HddvLGMuLrcWrM2mcFcoE5KfZGZLjV4bZwmWlDEeafBjIg/viewform*\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
                embed.WithColor(new Color(183, 126, 188));

                await Context.Channel.SendMessageAsync("", false, embed.Build());
            }
        }

        [Command("information")]
        public async Task info()
        {
            var embed = new EmbedBuilder();

            IReadOnlyCollection<SocketRole> Roles = Program.Client.GetGuild(457746527465766913).GetUser(Context.User.Id).Roles;
            var Owner = Context.Guild.Roles.FirstOrDefault(x => x.Name == "Owner");
            List<SocketRole> userroles = Roles.ToList();
            if (userroles.Contains(Owner) == true)
            {
                embed.WithTitle("***Information!***");
                embed.WithDescription($"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n**Channel Info**\n\n<#459610319594061824> | *Where I post all the information about this discord and the team*\n<#459611006230855680> | *Where I post the applications for people to apply for*\n<#459611025436704791> | *Where I post the rules to this discord*\n<#459611042419441675> | *Where I post the updates we make to this team*\n<#459611082076454922> | *Where I post all of the announcements*\n<#459611184669130763> | *Where you can see all of the commands for the bots if you're having trouble*\n<#459611224825659402> | *Where special messages are posted by reacting to them with a ⭐*\n<#459611455248138260> | *Where everyone chats*<#459611510793175050> | *Where you can access all of the bots except for <@292953664492929025>*\n<#459611242600857611> | *Where everyone can post ideas for videos, streams, and the discord server*\n\n**Server Info**\n\n**TwiddleMyBeatz** *is a gaming and music team. It has multiple leaders in it and was made by the two people below.*\n**•** <@!125383381176418304>\n**•** <@316767828634107904>\n\n**Contacts**\n\n**Discord** | *https://discord.me/twiddlebeatz or https://discord.gg/mR7evyz*\n**Youtube** | *https://www.youtube.com/channel/UCHAuqJ7n4Avqf3f8cn4lvYA?disable_polymer=true*\n**Twitch** | *https://www.twitch.tv/twiddlemybeatz*\n**Twitter** | *https://twitter.com/TwiddleBeatz*\n<#459611547837399060>  | *Where you can post pictures as long as they stay* **PG**\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
                embed.WithColor(new Color(183, 126, 188));

                await Context.Channel.SendMessageAsync("", false, embed.Build());
            }
        }

        [Command("Irules")]
        public async Task Irules()
        {
            var embed = new EmbedBuilder();

            IReadOnlyCollection<SocketRole> Roles = Program.Client.GetGuild(457746527465766913).GetUser(Context.User.Id).Roles;
            var Owner = Context.Guild.Roles.FirstOrDefault(x => x.Name == "Owner");
            List<SocketRole> userroles = Roles.ToList();
            if (userroles.Contains(Owner) == true)
            {
                embed.WithTitle("***Rules!***");
                embed.WithDescription($"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n***INFO***\n*This is a three strike zone! If you get three strikes than you're out! Here's how it works,*\n**• First Warning**\n**• Second Warning**\n**• Third Warning**\n**• First Strike** - *Mute for three days*\n**• Second Strike** - *Mute for 14 days*\n**• Third Strike** - *Ban :hammer:*\n\n**Rules**\n\n**I** | *NO ear raping*\n**II** | *Do NOT spam*\n**III** | *Be respectful to everyone here*\n**IV** | *Do NOT pose as a threat to anyone in this discord*\n**V** | *NO loopholes*\n**VI** | *Do NOT post inappropriate pictures  in <#459611547837399060>*\n**VII** | *Do NOT interrupt people while they are preforming and if people are talking, do NOT start preforming over them*\n**VIII** | *Do NOT do anything related to racial slurs in this discord*\n**IX** | *Do NOT beg for roles*\n**X** | *Use each text channel and voice channel for their designed purposes*\n**XI** | *NO advertising!*\n**XII** | *DON'T argue with staff! That won't get you any further!*\n**XIII** | *Have fun!*\n\n**Complaints**\n*If you have a complaint about this discord please fill out this application. If it is about someone please contact an <@&459599356140453889> member. Thank you! :heart:*\n\n*https://docs.google.com/forms/d/e/1FAIpQLSdeng1pwuoSOgMl0c4XilXTIWGOy-VFTFBOHn_SsBn0WziKKA/viewform*\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
                embed.WithColor(new Color(183, 126, 188));

                await Context.Channel.SendMessageAsync("", false, embed.Build());
            }
        }

        [Command("verify")]
        public async Task verify()
        {
            var embed = new EmbedBuilder();

            IReadOnlyCollection<SocketRole> Roles = Program.Client.GetGuild(457746527465766913).GetUser(Context.User.Id).Roles;
            var Owner = Context.Guild.Roles.FirstOrDefault(x => x.Name == "Owner");
            List<SocketRole> userroles = Roles.ToList();
            if (userroles.Contains(Owner) == true)
            {
                embed.WithTitle("***Welcome!***");
                embed.WithDescription($"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n**Hello User!** *Welcome to Musicord! This is a magical discord server full of musical people and gamers and... AND... ALL KINDS OF PEOPLE!! If you would like some assistance please directly message an <@&459599356140453889> member. Before you go any further into the server, we need you to go read <#459611025436704791> and when you're finished, please type* **``agree``** *. When you type this, this shows that you're acknowleding the rule. Thank you so much for joining! :D :heart:*\n\n**Keep in mind that when you type** **``agree``** **, you are agreeing to our rules.**\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
                embed.WithColor(new Color(183, 126, 188));

                await Context.Channel.SendMessageAsync("", false, embed.Build());
            }
        }

        [Command("botcommands")]
        public async Task botcommands()
        {
            var embed = new EmbedBuilder();

            IReadOnlyCollection<SocketRole> Roles = Program.Client.GetGuild(457746527465766913).GetUser(Context.User.Id).Roles;
            var Owner = Context.Guild.Roles.FirstOrDefault(x => x.Name == "Owner");
            List<SocketRole> userroles = Roles.ToList();
            if (userroles.Contains(Owner) == true)
            {
                embed.WithTitle("***Bot Commands!***");
                embed.WithDescription($"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n**Music Commands**\n\n*Rythm*\n**``!play (Song)\n!skip\n!loop\n!stop``**\n\n**Fun Commands**\n\n*Aki*\n**``!aki start\n!aki invite\n!aki stop``**\n*Nadeko*\n**``.iam (role)``**\n*Starboard*\n**``React to a message with a ⭐ to pin it in <#459611224825659402>``**\n*Unbelievaboat*\n**``!shop\n!buy (item) [amount]\n!work\n!cockfight [bet] (You must buy a chicken first)``**\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
                embed.WithColor(new Color(183, 126, 188));

                await Context.Channel.SendMessageAsync("", false, embed.Build());
            }
        }
    }
}
