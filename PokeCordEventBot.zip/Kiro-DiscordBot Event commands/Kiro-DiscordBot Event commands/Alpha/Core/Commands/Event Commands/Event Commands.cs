﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Discord;
using Discord.Commands;
using Discord.WebSocket;
using Newtonsoft.Json;
using System.IO;
using System.Collections.Generic;
using System.Diagnostics;

namespace Alpha.Core.Commands.Event_Commands
{
    public class Event_Commands : ModuleBase<SocketCommandContext>
    {
        public static List<ulong> Queue = new List<ulong>();
        public static bool Begin = false;
        public static bool Open = false;
        public static SocketGuildUser CurrentUserPerformer;
        public static bool FirstJoined = false;
        public static IUserMessage TimerMsg;

        [Command("join")]
        public async Task join()
        {
            if (Begin == true && Open == true)
            {
                if (FirstJoined == false)
                {
                    CurrentUserPerformer = Context.Client.GetGuild(379513710563033092).GetUser(Context.User.Id);
                    var role = Context.Guild.Roles.FirstOrDefault(x => x.Name == "CurrentPerformer");
                    Queue.Add(Context.User.Id);
                    await CurrentUserPerformer.AddRoleAsync(role);
                    var embed = new EmbedBuilder();
                    embed.WithTitle("Welcome!");
                    embed.WithDescription($"{Context.User.Mention} Welcome to the queue!");
                    embed.WithColor(new Color(183, 126, 188));
                    embed.WithThumbnailUrl(Context.User.GetAvatarUrl());
                    embed.WithFooter("Please join with +join. Also, please respect every performer! 🎶");


                    await Context.Channel.SendMessageAsync("", false, embed.Build());
                    FirstJoined = true;
                }
                else if (Queue.Contains(Context.User.Id))
                {
                    var embed = new EmbedBuilder();
                    embed.WithTitle("**Oops!**");
                    embed.WithDescription("You're already in the queue silly!");
                    embed.WithColor(new Color(183, 126, 188));
                    embed.WithThumbnailUrl(Context.User.GetAvatarUrl());
    

                    await Context.Channel.SendMessageAsync("", false, embed.Build());
                }
                else
                {
                    Queue.Add(Context.User.Id);
                    SocketGuildUser user = Program.Client.GetGuild(379513710563033092).GetUser(Context.User.Id);
                    var MuteRole = Context.Guild.Roles.FirstOrDefault(x => x.Name == "EventMute");
                    await user.AddRoleAsync(MuteRole);

                    var embed = new EmbedBuilder();
                    embed.WithTitle("Welcome!");
                    embed.WithDescription($"{Context.User.Mention} Welcome to the queue!");
                    embed.WithColor(new Color(183, 126, 188));
                    embed.WithThumbnailUrl(Context.User.GetAvatarUrl());
    

                    await Context.Channel.SendMessageAsync("", false, embed.Build());
                }
            } 
            
            
            if (Begin == true && Open == false)
            {
                var embed = new EmbedBuilder();
                embed.WithTitle("**Sorry!**");
                embed.WithDescription("The queue is closed! Get to the events early to join faster!");
                embed.WithColor(new Color(183, 126, 188));
                embed.WithThumbnailUrl(Context.User.GetAvatarUrl());

                await Context.Channel.SendMessageAsync("", false, embed.Build());
            }
            if (Begin == false)
            {
                var embed = new EmbedBuilder();
                embed.WithTitle("**Oops!**");
                embed.WithDescription("There's no event going on right now!");
                embed.WithColor(new Color(183, 126, 188));
                embed.WithThumbnailUrl(Context.User.GetAvatarUrl());

                await Context.Channel.SendMessageAsync("", false, embed.Build());
            }
        }

        [Command("begin")]
        public async Task HasBegun()
        {
            IReadOnlyCollection<SocketRole> Roles = Program.Client.GetGuild(379513710563033092).GetUser(Context.User.Id).Roles;
            var EventOrg = Context.Guild.Roles.FirstOrDefault(x => x.Name == "Event Organizer");
            List<SocketRole> userroles = Roles.ToList();
            if (userroles.Contains(EventOrg) == true)
            {
                if (Begin == true)
                {
                    var embed = new EmbedBuilder();
                    embed.WithTitle("**Oops!**");
                    embed.WithDescription("There's already an event going on!");
                    embed.WithColor(new Color(183, 126, 188));
                    embed.WithThumbnailUrl(Context.Guild.IconUrl);

                    await Context.Channel.SendMessageAsync("", false, embed.Build());
                }
                else
                {
                    Begin = true;

                    var embed = new EmbedBuilder();
                    embed.WithTitle("**Event Started!**");
                    embed.WithDescription("The event has started! Let's have some fun!");
                    embed.WithColor(new Color(183, 126, 188));
                    embed.WithThumbnailUrl(Context.Guild.IconUrl);

                    await Context.Channel.SendMessageAsync("", false, embed.Build());
                    {
                        embed.WithTitle("**Event Started!**");
                        embed.WithDescription($"Event started at {DateTime.Now}");
                        embed.WithColor(new Color(183, 126, 188));
                        embed.WithThumbnailUrl(Context.Guild.IconUrl);

                        await Context.User.SendMessageAsync("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
                        await Context.User.SendMessageAsync("", false, embed.Build());
                    }
                }
            }
            else
            {
                var embed = new EmbedBuilder();
                embed.WithTitle("**Sorry!**");
                embed.WithDescription("You're not an event organizer!");
                embed.WithColor(new Color(183, 126, 188));
                embed.WithThumbnailUrl(Context.User.GetAvatarUrl());

                await Context.Channel.SendMessageAsync("", false, embed.Build());
            }
        }

        [Command("end")]
        public async Task end()
        {
            IReadOnlyCollection<SocketRole> Roles = Program.Client.GetGuild(379513710563033092).GetUser(Context.User.Id).Roles;
            var EventOrg = Context.Guild.Roles.FirstOrDefault(x => x.Name == "Event Organizer");
            List<SocketRole> userroles = Roles.ToList();
            if (userroles.Contains(EventOrg) == true)
            {
                if (Begin == true)
                {
                    Begin = false;
                    Queue.Clear();

                    var embed = new EmbedBuilder();
                    embed.WithTitle("**Ended!**");
                    embed.WithDescription($"Event Ended at {DateTime.Now}");
                    embed.WithColor(new Color(183, 126, 188));
                    embed.WithThumbnailUrl(Context.Guild.IconUrl);

                    await Context.Channel.SendMessageAsync("", false, embed.Build());
                    {
                        embed.WithTitle("**Ended!**");
                        embed.WithDescription($"Event Ended at {DateTime.Now}");
                        embed.WithColor(new Color(183, 126, 188));
                        embed.WithThumbnailUrl(Context.Guild.IconUrl);

                        await Context.User.SendMessageAsync("", false, embed.Build());
                    }
                }
                else
                {
                    var embed = new EmbedBuilder();
                    embed.WithTitle("**No Event!**");
                    embed.WithDescription("**There's no event going on :sob:**");
                    embed.WithColor(new Color(183, 126, 188));
                    embed.WithThumbnailUrl(Context.Guild.IconUrl);

                    await Context.Channel.SendMessageAsync("", false, embed.Build());
                }
            }
            else
            {
                var embed = new EmbedBuilder();
                embed.WithTitle("**Sorry!**");
                embed.WithDescription("You're not an event organizer!");
                embed.WithColor(new Color(183, 126, 188));
                embed.WithThumbnailUrl(Context.User.GetAvatarUrl());

                await Context.Channel.SendMessageAsync("", false, embed.Build());
            }
        }

        [Command("open")]
        public async Task HasOpened()
        {
            IReadOnlyCollection<SocketRole> Roles = Program.Client.GetGuild(379513710563033092).GetUser(Context.User.Id).Roles;
            var EventOrg = Context.Guild.Roles.FirstOrDefault(x => x.Name == "Event Organizer");
            List<SocketRole> userroles = Roles.ToList();
            if (userroles.Contains(EventOrg) == true)
            {
                if (Begin == true)
                {
                    Open = true;

                    var embed = new EmbedBuilder();
                    embed.WithTitle("**Open!**");
                    embed.WithDescription("The queue is open! Go ahead and join with **``+join``**! :microphone2:");
                    embed.WithColor(new Color(183, 126, 188));
                    embed.WithThumbnailUrl(Context.Guild.IconUrl);

                    await Context.Channel.SendMessageAsync("", false, embed.Build());
                }
                else
                {
                    var embed = new EmbedBuilder();
                    embed.WithTitle("**No Event!**");
                    embed.WithDescription("**There's no event going on :sob:**");
                    embed.WithColor(new Color(183, 126, 188));
                    embed.WithThumbnailUrl(Context.Guild.IconUrl);

                    await Context.Channel.SendMessageAsync("", false, embed.Build());
                }
            }
            else
            {
                var embed = new EmbedBuilder();
                embed.WithTitle("**Sorry!**");
                embed.WithDescription("You're not an event organizer!");
                embed.WithColor(new Color(183, 126, 188));
                embed.WithThumbnailUrl(Context.User.GetAvatarUrl());

                await Context.Channel.SendMessageAsync("", false, embed.Build());
            }
        }

        [Command("remove")]
        public async Task HasRemoved(IGuildUser user)
        {
            IReadOnlyCollection<SocketRole> Roles = Program.Client.GetGuild(379513710563033092).GetUser(Context.User.Id).Roles;
            var EventOrg = Context.Guild.Roles.FirstOrDefault(x => x.Name == "Event Organizer");
            List<SocketRole> userroles = Roles.ToList();
            if (userroles.Contains(EventOrg) == true)
            {
                if (Queue.Contains(user.Id))
                {
                    Queue.RemoveAll(r => r == user.Id);

                    var embed = new EmbedBuilder();
                    embed.WithTitle("**Gone!**");
                    embed.WithDescription($"**{user} has been removed from the queue!**");
                    embed.WithColor(new Color(183, 126, 188));
                    embed.WithThumbnailUrl(Context.Guild.IconUrl);

                    await Context.Channel.SendMessageAsync("", false, embed.Build());
                }
                else
                {
                    var embed = new EmbedBuilder();
                    embed.WithTitle("**Nope!**");
                    embed.WithDescription("**This user isn't in the queue!**");
                    embed.WithColor(new Color(183, 126, 188));
                    embed.WithThumbnailUrl(Context.Guild.IconUrl);

                    await Context.Channel.SendMessageAsync("", false, embed.Build());
                }
            }
            else
            {
                var embed = new EmbedBuilder();
                embed.WithTitle("**Sorry!**");
                embed.WithDescription("You're not an event organizer!");
                embed.WithColor(new Color(183, 126, 188));
                embed.WithThumbnailUrl(Context.User.GetAvatarUrl());

                await Context.Channel.SendMessageAsync("", false, embed.Build());
            }
        }

        [Command("next")]
        public async Task Hasnext()
        {
            IReadOnlyCollection<SocketRole> Roles = Program.Client.GetGuild(379513710563033092).GetUser(Context.User.Id).Roles;
            var EventOrg = Context.Guild.Roles.FirstOrDefault(x => x.Name == "Event Organizer");
            List<SocketRole> userroles = Roles.ToList();
            if (userroles.Contains(EventOrg) == true)
            {
                if (Begin == true)
                {
                    string QueueMsg = "";
                    int Position = -1;
                    foreach (ulong item in Queue)

                        if (Queue.Count > 1)
                        { 
                                    SocketGuildUser removinguser = Context.Client.GetGuild(379513710563033092).GetUser(Queue[0]);
                                    var role = Context.Guild.Roles.FirstOrDefault(x => x.Name == "CurrentPerformer");
                                    await removinguser.RemoveRoleAsync(role);
                                    Queue.RemoveAt(0);
                                    CurrentUserPerformer = Program.Client.GetGuild(379513710563033092).GetUser(Queue[0]);
                                    await CurrentUserPerformer.AddRoleAsync(role);
                                    string mention = "<@!" + CurrentUserPerformer.Id + ">";
                                    //string mention = "<@!" + Queue[0].ToString() + ">";

                                    await Context.Channel.SendMessageAsync($"{CurrentUserPerformer} is up next! Go show them some love!");
                                    await Context.User.SendMessageAsync($"**{CurrentUserPerformer} - {CurrentUserPerformer.Id}**");
                        }
                        else
                        {
                            var embed = new EmbedBuilder();
                            embed.WithTitle("**Error!**");
                            embed.WithDescription("**There's no one else in the queue!**");
                            embed.WithColor(new Color(183, 126, 188));
                            embed.WithThumbnailUrl(Context.Guild.IconUrl);

                            await Context.Channel.SendMessageAsync("", false, embed.Build());
                        }
                }
                if (Begin == false)
                {
                    var embed = new EmbedBuilder();
                    embed.WithTitle("**?**");
                    embed.WithDescription("**There's no event?!**");
                    embed.WithColor(new Color(183, 126, 188));
                    embed.WithThumbnailUrl(Context.Guild.IconUrl);

                    await Context.Channel.SendMessageAsync("", false, embed.Build());
                }
            }
            else
            {
                var embed = new EmbedBuilder();
                embed.WithTitle("**Sorry!**");
                embed.WithDescription("You're not an event organizer!");
                embed.WithColor(new Color(183, 126, 188));
                embed.WithThumbnailUrl(Context.User.GetAvatarUrl());

                await Context.Channel.SendMessageAsync("", false, embed.Build());
            }
        }

        [Command("queue")]
        public async Task HasQueue()
        {
            IReadOnlyCollection<SocketRole> Roles = Program.Client.GetGuild(379513710563033092).GetUser(Context.User.Id).Roles;
            var EventOrg = Context.Guild.Roles.FirstOrDefault(x => x.Name == "Event Organizer");
            List<SocketRole> userroles = Roles.ToList();
            if (userroles.Contains(EventOrg) == true)
            {
                if (Open == true || Open == false)
                {
                    string QueueMsg = "";
                    int Position = -1;
                    foreach (ulong item in Queue)
                    {
                        if (Position == -1)
                        {
                            CurrentUserPerformer = Program.Client.GetGuild(379513710563033092).GetUser(item);
                            QueueMsg = QueueMsg + "Current Performer" + "<@!" + CurrentUserPerformer.Id + ">" + "\n\n**CurrentQueue**\n";
                            Position++;
                        }
                        else
                        {
                            Position++;
                            QueueMsg = QueueMsg + "#" + Position + "<@!" + item + ">" + "\n";
                        }

                    }

                    var embed = new EmbedBuilder();
                    embed.WithTitle("**Queue!**");
                    embed.WithDescription($"{QueueMsg}");
                    embed.WithColor(new Color(183, 126, 188));
                    embed.WithThumbnailUrl(Context.User.GetAvatarUrl());
                    embed.WithFooter("Please join with +join. Also, please respect every performer! 🎶");

                    await Context.Channel.SendMessageAsync("", false, embed.Build());
                }
                else if (Begin == false)
                {
                    var embed = new EmbedBuilder();
                    embed.WithTitle("**?**");
                    embed.WithDescription("**There's no event?!**");
                    embed.WithColor(new Color(183, 126, 188));
                    embed.WithThumbnailUrl(Context.Guild.IconUrl);

                    await Context.Channel.SendMessageAsync("", false, embed.Build());
                }
            }
            else
            {
                string QueueMsg = "";
                int Position = -1;
                foreach (ulong item in Queue)
                {
                    if (Position == -1)
                    {
                        CurrentUserPerformer = Program.Client.GetGuild(379513710563033092).GetUser(item);
                        QueueMsg = QueueMsg + "Current Performer" + "<@!" + CurrentUserPerformer.Id + ">" + "\n\n**CurrentQueue**\n";
                        Position++;
                    }
                    else
                    {
                        Position++;
                        QueueMsg = QueueMsg + "#" + Position + "<@!" + item + ">" + "\n";
                    }

                }

                var embed = new EmbedBuilder();
                embed.WithTitle("**Queue!**");
                embed.WithDescription($"{QueueMsg}");
                embed.WithColor(new Color(183, 126, 188));
                embed.WithThumbnailUrl(Context.User.GetAvatarUrl());
                embed.WithFooter("Please join with +join. Also, please respect every performer! 🎶");

                await Context.User.SendMessageAsync("", false, embed.Build());
            }
        }

        [Command("close")]
        public async Task HasClosed()
        {
            IReadOnlyCollection<SocketRole> Roles = Program.Client.GetGuild(379513710563033092).GetUser(Context.User.Id).Roles;
            var EventOrg = Context.Guild.Roles.FirstOrDefault(x => x.Name == "Event Organizer");
            List<SocketRole> userroles = Roles.ToList();
            if (userroles.Contains(EventOrg) == true)
            {
                if (Begin == true && Open == true)
                {
                    Open = false;

                    var embed = new EmbedBuilder();
                    embed.WithTitle("**Closed!**");
                    embed.WithDescription("The queue is closed! Go ahead and join another time! :microphone2:");
                    embed.WithColor(new Color(183, 126, 188));
                    embed.WithThumbnailUrl(Context.Guild.IconUrl);

                    await Context.Channel.SendMessageAsync("", false, embed.Build());
                }
                if (Begin == false)
                {
                    var embed = new EmbedBuilder();
                    embed.WithTitle("**No Event!**");
                    embed.WithDescription("There's no event going on :sob:");
                    embed.WithColor(new Color(183, 126, 188));
                    embed.WithThumbnailUrl(Context.Guild.IconUrl);

                    await Context.Channel.SendMessageAsync("", false, embed.Build());
                }
            }
            else
            {
                var embed = new EmbedBuilder();
                embed.WithTitle("**Sorry!**");
                embed.WithDescription("You're not an event organizer!");
                embed.WithColor(new Color(183, 126, 188));
                embed.WithThumbnailUrl(Context.User.GetAvatarUrl());

                await Context.Channel.SendMessageAsync("", false, embed.Build());
            }
        }

        [Command("mute")]
        public async Task mute()
        {
            IReadOnlyCollection<SocketRole> Roles = Program.Client.GetGuild(379513710563033092).GetUser(Context.User.Id).Roles;
            var EventOrg = Context.Guild.Roles.FirstOrDefault(x => x.Name == "Event Organizer");
            List<SocketRole> userroles = Roles.ToList();
            if (userroles.Contains(EventOrg) == true)
            {
                IReadOnlyCollection<SocketGuildUser> Users = Program.Client.GetGuild(379513710563033092).GetVoiceChannel(497463850988339221).Users;
                List<SocketGuildUser> SocketUsers = Users.ToList();
                foreach (SocketGuildUser user in SocketUsers)
                {
                    var PreformerRole = Context.Guild.Roles.FirstOrDefault(x => x.Name == "CurrentPerformer");
                    if (userroles.Contains(PreformerRole) == true)
                    {
                        var MuteRole = Context.Guild.Roles.FirstOrDefault(x => x.Name == "EventMute");
                        await user.AddRoleAsync(MuteRole);
                    }
                    else
                    {
                        var MuteRole = Context.Guild.Roles.FirstOrDefault(x => x.Name == "EventMute");
                        await user.AddRoleAsync(MuteRole);
                    }
                    //foreach (SocketRole role in userroles)
                    //{
                    //    if (role.Name == "CurrentPerformer")
                    //    {

                    //    }
                    //    else
                    //    {
                    //        var MuteRole = Context.Guild.Roles.FirstOrDefault(x => x.Name == "EventMute");
                    //        await user.AddRoleAsync(MuteRole);
                    //    }
                    //}
                }
                

                var embed = new EmbedBuilder();
                embed.WithTitle("**Mute!**");
                embed.WithDescription("Users in the channel have been muted!");
                embed.WithColor(new Color(183, 126, 188));
                embed.WithThumbnailUrl(Context.Guild.IconUrl);

                await Context.Channel.SendMessageAsync("", false, embed.Build());
            }
            else
            {
                var embed = new EmbedBuilder();
                embed.WithTitle("**Sorry!**");
                embed.WithDescription("You're not an event organizer!");
                embed.WithColor(new Color(183, 126, 188));
                embed.WithThumbnailUrl(Context.User.GetAvatarUrl());

                await Context.Channel.SendMessageAsync("", false, embed.Build());
            }
        }

        [Command("unmute")]
        public async Task unmute()
        {
            IReadOnlyCollection<SocketRole> Roles = Program.Client.GetGuild(379513710563033092).GetUser(Context.User.Id).Roles;
            var EventOrg = Context.Guild.Roles.FirstOrDefault(x => x.Name == "Event Organizer");
            List<SocketRole> userroles = Roles.ToList();
            if (userroles.Contains(EventOrg) == true)
            {
                IReadOnlyCollection<SocketGuildUser> Users = Program.Client.GetGuild(379513710563033092).GetVoiceChannel(497463850988339221).Users;
                List<SocketGuildUser> SocketUsers = Users.ToList();
                foreach (SocketGuildUser user in SocketUsers)

                {
                    var PreformerRole = Context.Guild.Roles.FirstOrDefault(x => x.Name == "CurrentPerformer");
                    var EventMuteRole = Context.Guild.Roles.FirstOrDefault(x => x.Name == "EventMute");


                    if (userroles.Contains(PreformerRole) == true)
                    {
                        if (userroles.Contains(PreformerRole) == true)
                        {
                            await user.RemoveRoleAsync(PreformerRole);
                        }
                    }
                    else
                    {
                        if (userroles.Contains(EventMuteRole) == true)
                        {
                            await user.RemoveRoleAsync(EventMuteRole);
                        }
                    }
                }

                var embed = new EmbedBuilder();
                embed.WithTitle("Yay!");
                embed.WithDescription("Users in the channel have been unmuted!");
                embed.WithColor(new Color(183, 126, 188));
                embed.WithThumbnailUrl(Context.Guild.IconUrl);

                await Context.Channel.SendMessageAsync("", false, embed.Build());
            }
            else
            {
                var embed = new EmbedBuilder();
                embed.WithTitle("**Sorry!**");
                embed.WithDescription("You're not an event organizer!");
                embed.WithColor(new Color(183, 126, 188));
                embed.WithThumbnailUrl(Context.User.GetAvatarUrl());

                await Context.Channel.SendMessageAsync("", false, embed.Build());
            }
        }

        [Command("grab")]
        public async Task grab(IGuildUser user)
        {
            IReadOnlyCollection<SocketRole> Roles = Program.Client.GetGuild(379513710563033092).GetUser(Context.User.Id).Roles;
            var Staff = Context.Guild.Roles.FirstOrDefault(x => x.Name == "Staff");
            List<SocketRole> userroles = Roles.ToList();
            if (userroles.Contains(Staff) == true)
            {
                var embed = new EmbedBuilder();
                embed.WithTitle("**Grabbed!**");
                embed.WithDescription($"**{user}'s ID is,**\n*{user.Id}*");
                embed.WithColor(new Color(183, 126, 188));
                embed.WithThumbnailUrl(user.GetAvatarUrl());

                await Context.Channel.SendMessageAsync("", false, embed.Build());
            }
            else
            {
                var embed = new EmbedBuilder();
                embed.WithTitle("**Sorry!**");
                embed.WithDescription("You're not an event organizer!");
                embed.WithColor(new Color(183, 126, 188));
                embed.WithThumbnailUrl(Context.User.GetAvatarUrl());

                await Context.Channel.SendMessageAsync("", false, embed.Build());
            }
        }

        [Command("eventhelp")]
        public async Task eventhelp()
        {
            {
                var embed = new EmbedBuilder();
                embed.WithTitle("**Event Commands!**");
                embed.WithDescription("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n**``+begin``** - *Begin the event*\n**``+open``** - *Open the queue*\n**``+join``** - *Join the event*\n**``+close``** - *Close the event*\n**``+end``** - *End the event*\n**``+remove [user]``** - *Remove the user from the queue*\n**``+queue``** - *View the queue*\n**``+next``** - *Go to the next user*\n**``+mute``** - *Mute every user in the queue*\n**``+unmute``** - *Unmute every user in the queue*\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
                embed.WithColor(new Color(183, 126, 188));
                embed.WithThumbnailUrl(Context.Guild.IconUrl);

                await Context.Channel.SendMessageAsync("", false, embed.Build());
            }

        }

        [Command("time")]
        public async Task timer(int time, string amount)
        {
            IReadOnlyCollection<SocketRole> Roles = Program.Client.GetGuild(379513710563033092).GetUser(Context.User.Id).Roles;
            var EventOrg = Context.Guild.Roles.FirstOrDefault(x => x.Name == "Event Organizer");
            List<SocketRole> userroles = Roles.ToList();
            if (userroles.Contains(EventOrg) == true)
            {
                {
                    if (amount == "minute" || amount == "m" || amount == "minutes" || amount == "min" || amount == "mins")
                    {
                        time = (int)TimeSpan.FromMinutes(time).TotalMilliseconds;
                    }
                    if (amount == "second" || amount == "s" || amount == "seconds" || amount == "sec" || amount == "secs")
                    {
                        time = (int)TimeSpan.FromSeconds(time).TotalMilliseconds;
                    }
                    if (amount == "hour" || amount == "h" || amount == "hours" || amount == "hr" || amount == "hrs")
                    {
                        time = (int)TimeSpan.FromHours(time).TotalMilliseconds;
                    }
                    System.Timers.Timer aTimer = new System.Timers.Timer();
                    aTimer.Interval = time;
                    aTimer.Enabled = true;
                    Stopwatch stopwatch = new Stopwatch();
                    stopwatch.Start();

                    TimerMsg = await Context.Channel.SendMessageAsync("Timer Has Started!");
                    while (aTimer.Enabled == true)
                    {
                        await TimerMsg.ModifyAsync(x =>
                        {
                            TimeSpan ts = stopwatch.Elapsed;
                            string sTime = string.Format("Time Elapsed: {0}h {1}m {2}s", ts.Hours, ts.Minutes, ts.Seconds);
                            x.Content = sTime;
                        });
                    }
                }
            }
            else
            {
                var embed = new EmbedBuilder();
                embed.WithTitle("**Sorry!**");
                embed.WithDescription("You're not an event organizer!");
                embed.WithColor(new Color(183, 126, 188));
                embed.WithThumbnailUrl(Context.User.GetAvatarUrl());

                await Context.Channel.SendMessageAsync("", false, embed.Build());
            }

        }

        [Command("grab")]
        public async Task graber()
        {
            IReadOnlyCollection<SocketRole> Roles = Program.Client.GetGuild(379513710563033092).GetUser(Context.User.Id).Roles;
            var Staff = Context.Guild.Roles.FirstOrDefault(x => x.Name == "Staff");
            List<SocketRole> userroles = Roles.ToList();
            if (userroles.Contains(Staff) == true)
            {
                var embed = new EmbedBuilder();
                embed.WithTitle("**Grabbed!**");
                embed.WithDescription($"**{Context.User}'s ID is,**\n*{Context.User.Id}*");
                embed.WithColor(new Color(183, 126, 188));
                embed.WithThumbnailUrl(Context.User.GetAvatarUrl());

                await Context.Channel.SendMessageAsync("", false, embed.Build());
            }
            else
            {
                var embed = new EmbedBuilder();
                embed.WithTitle("**Sorry!**");
                embed.WithDescription("You're not an event organizer!");
                embed.WithColor(new Color(183, 126, 188));
                embed.WithThumbnailUrl(Context.User.GetAvatarUrl());

                await Context.Channel.SendMessageAsync("", false, embed.Build());
            }
        }
    } 
}
